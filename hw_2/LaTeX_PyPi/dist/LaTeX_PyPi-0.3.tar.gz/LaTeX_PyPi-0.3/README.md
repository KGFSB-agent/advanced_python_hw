# LaTeX_img_tab #
This module is a training and homework assignment for Python + LaTeX (generating tables and images)